# Cricketer's Profile

Mobile-first starter website for a Bangladesh grassroots cricket statistics platform.

## Current status
- Responsive homepage and navigation
- Demo player cards with permanent-ID format examples
- Tournament listing examples
- Scorecard verification workflow explainer
- No live database, login, score submission, or real player records yet
- Demo data is clearly labelled and must not be treated as verified statistics

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Run `npm run dev`.
4. Open http://localhost:3000.

## Next development phase
Connect Supabase, then implement player registration, unique Player IDs, teams, tournaments, match scorecards, approval workflow, audit log, and ball-based cricket statistics calculations.

Do not add real player statistics until score verification and authorization controls are implemented.
