import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Cricketer's Profile | Bangladesh Cricket Database",
  description: "Player profiles, tournaments, scorecards and verified cricket statistics from Bangladesh."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
