const players = [
  { id: "CPB-000001", name: "Sample Player One", role: "Batter", matches: 42, runs: 1284, wickets: 3 },
  { id: "CPB-000002", name: "Sample Player Two", role: "All-rounder", matches: 36, runs: 642, wickets: 41 },
  { id: "CPB-000003", name: "Sample Player Three", role: "Bowler", matches: 29, runs: 118, wickets: 52 }
];

const tournaments = [
  { name: "Chattogram Local T20 Cup", status: "Completed", matches: 18 },
  { name: "Bangladesh Community Cricket League", status: "Registration", matches: 24 },
  { name: "Weekend Champions Trophy", status: "Upcoming", matches: 12 }
];

function SectionTitle({ eyebrow, title, href = "#" }: { eyebrow: string; title: string; href?: string }) {
  return <div className="section-title"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div><a href={href}>View all <span>↗</span></a></div>;
}

export default function Home() {
  return <main>
    <nav className="nav wrap">
      <a className="brand" href="#"><span className="brand-mark">CP</span><span>Cricketer&apos;s <b>Profile</b><small> BANGLADESH CRICKET DATABASE</small></span></a>
      <div className="nav-links"><a href="#players">Players</a><a href="#tournaments">Tournaments</a><a href="#scorecards">Scorecards</a><a href="#rankings">Rankings</a></div>
      <a className="nav-button" href="#organizer">Organizer Login</a>
    </nav>

    <section className="hero">
      <div className="wrap hero-grid">
        <div className="hero-copy">
          <div className="pill"><span className="live-dot"></span> BANGLADESH GRASSROOTS CRICKET</div>
          <h1>Every player.<br/><em>Every performance.</em><br/>One profile.</h1>
          <p>A home for local cricket in Bangladesh. Explore player careers, follow tournaments and discover verified match statistics.</p>
          <div className="hero-actions"><a className="primary" href="#players">Explore players <span>→</span></a><a className="secondary" href="#tournaments">Browse tournaments</a></div>
          <div className="hero-note"><span>✓</span> Career statistics update after scorecard verification.</div>
        </div>
        <div className="hero-art" aria-label="Cricket themed illustration">
          <div className="art-ring ring-one"></div><div className="art-ring ring-two"></div>
          <div className="art-ball">●</div><div className="art-stumps"><i></i><i></i><i></i><b></b><b></b></div>
          <div className="art-caption"><small>THE GAME. THE NUMBERS.</small><strong>MADE<br/>VISIBLE.</strong></div>
          <div className="art-tag">EST. 2026 <span>•</span> BANGLADESH</div>
        </div>
      </div>
    </section>

    <section className="stats-strip"><div className="wrap stats-grid"><div><strong>01</strong><span>Player profiles</span></div><div><strong>02</strong><span>Verified scorecards</span></div><div><strong>03</strong><span>Career statistics</span></div><div><strong>∞</strong><span>Local cricket stories</span></div></div></section>

    <section className="section wrap" id="players">
      <SectionTitle eyebrow="PLAYER DIRECTORY" title="Find your cricketer" />
      <div className="searchbar"><span>⌕</span><input aria-label="Search players" placeholder="Search by player name or Player ID (coming soon)" /><button type="button">Search</button></div>
      <div className="player-grid">{players.map((p) => <article className="player-card" key={p.id}><div className="avatar">{p.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</div><div className="player-info"><span className="player-id">{p.id}</span><h3>{p.name}</h3><span className="role">{p.role}</span></div><div className="player-numbers"><div><b>{p.matches}</b><small>MATCHES</small></div><div><b>{p.runs}</b><small>RUNS</small></div><div><b>{p.wickets}</b><small>WICKETS</small></div></div><div className="card-foot">DEMO PROFILE <span>↗</span></div></article>)}</div>
      <p className="demo-note">Sample profiles are demonstration data only, not real player records.</p>
    </section>

    <section className="section tournament-section" id="tournaments"><div className="wrap"><SectionTitle eyebrow="ON THE CALENDAR" title="Tournaments & competitions" /><div className="tournament-grid">{tournaments.map((t,i)=><article className="tournament-card" key={t.name}><div className="tourney-index">0{i+1}</div><div><span className="role">{t.status}</span><h3>{t.name}</h3><p>{t.matches} scheduled matches</p></div><span className="arrow">↗</span></article>)}</div></div></section>

    <section className="section wrap feature-grid" id="scorecards"><div><span className="eyebrow">TRUST IN THE SCORE</span><h2>Statistics that<br/><em>mean something.</em></h2><p>Scorecards submitted by tournament organizers move through a review process. Only approved results contribute to a player&apos;s official career record.</p><a className="text-link" href="#organizer">How verification works →</a></div><div className="verification"><div className="verify-head"><span>RESULT VERIFICATION</span><span className="verify-icon">✓</span></div><div className="verify-step"><b>01</b><div><strong>Scorecard submitted</strong><small>Manual entry or image/PDF upload</small></div><span className="step-status">RECEIVED</span></div><div className="verify-step"><b>02</b><div><strong>Organizer review</strong><small>Check players, totals and match details</small></div><span className="step-status pending">REVIEW</span></div><div className="verify-step"><b>03</b><div><strong>Verified result</strong><small>Approved stats update career records</small></div><span className="step-status approved">APPROVED</span></div></div></section>

    <section className="cta" id="organizer"><div className="wrap cta-inner"><div><span className="eyebrow">GROW THE GAME</span><h2>Bring your tournament<br/>into the record.</h2><p>Organizer tools and score submission will be available in a future release.</p></div><a className="primary" href="mailto:hello@cricketersprofile.example">Register interest <span>→</span></a></div></section>
    <footer><div className="wrap footer-inner"><a className="brand" href="#"><span className="brand-mark">CP</span><span>Cricketer&apos;s <b>Profile</b><small> BANGLADESH CRICKET DATABASE</small></span></a><span>Independent grassroots cricket records · Bangladesh</span><span>© 2026 Cricketer&apos;s Profile</span></div></footer>
  </main>;
}
